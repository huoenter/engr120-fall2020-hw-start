#!/usr/bin/env bash

apt-get update
apt-get install -y make
apt-get install -y gcc
apt-get install -y python # python-pip python-dev
# apt-get install -y valgrind

# pip install -r /autograder/source/requirements.txt
